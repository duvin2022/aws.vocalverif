pour la config, voir le fichier email.php
mettez y votre email et dans le  cas ou vous vouslez recevoir
par teleram remplissez les champs "token_bot" et "chat_id"